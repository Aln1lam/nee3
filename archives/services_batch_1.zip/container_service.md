# 服务详解：`backend/services/container_service.py`

职责：与 Docker 交互，创建/销毁容器、查询状态、获取日志、清理过期实例、续期等。

主要方法：`create_container`, `destroy_container`, `get_container_status`, `cleanup_expired_containers`, `list_user_containers`, `renew_container_lease`, `get_container_logs`。

注意：生产环境需确保 Docker 权限、安全网络与资源配额；建议对 `create_container` 做限流与配额校验。
