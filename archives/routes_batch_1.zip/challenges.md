# 路由详解：`backend/route/challenges.py`

概述：此模块实现与 CTF 题目相关的所有 API，包含题目列表/详情、提交 Flag、排行榜、提示系统、作弊检测、容器实例管理与题目统计等核心功能。

主要端点（摘要）：

- `GET /games/<game_id>/challenges`
  - 鉴权：公开
  - 描述：返回指定竞赛的题目列表（仅启用的题目）。
  - 返回：{ code, msg, data: [challenge] }

- `GET /<challenge_id>`
  - 鉴权：`@jwt_required()`
  - 描述：获取题目详情并附带当前用户的提交记录与是否已解。
  - 返回：{ code, msg, data: { challenge, submissions, submission_count, is_solved } }

- `POST /<challenge_id>/submit`
  - 鉴权：`@jwt_required()`
  - 描述：提交 Flag；实现包括答案校验、动态分数计算、血液奖励（首解/二解/三解）、作弊检测、排分更新、赛季统计触发与容器销毁（正确时）。
  - 请求体：{ answer: string }
  - 常见返回：正确时返回最终得分、血液等级、加成倍数；错误时返回相应错误码与消息。

- `GET /games/<game_id>/scoreboard`
  - 鉴权：公开
  - 描述：获取比赛实时排行榜（由 `ScoringService.calculate_rankings` 计算）。

- `GET /games/<game_id>/first-solves`
  - 鉴权：公开
  - 描述：获取首解/二解/三解记录。

- `GET /<challenge_id>/hints`
  - 鉴权：`@jwt_required()`
  - 描述：获取题目的提示列表，并标注当前用户已访问的提示。

- `POST /<hint_id>/access-hint`
  - 鉴权：`@jwt_required()`
  - 描述：记录用户查看提示的行为；如果提示配置了扣分，会更新排行榜分数。

- `GET /games/<game_id>/cheat-info`
  - 鉴权：`@jwt_required()`（需管理员权限）
  - 描述：管理员获取作弊检测信息（`CtfCheatInfo` 记录）。

- 容器/实例管理端点：
  - `GET /<challenge_id>/container-status`：查询用户该题目的容器状态（no_container/running/expired）。
  - `POST /<challenge_id>/start-container`：启动题目容器（集成 `container_service.create_container` 与流量捕获）。
  - `POST /<challenge_id>/start-instance`：为动态题目创建实例记录（1小时到期，支持流量捕获）。
  - `POST /instances/<instance_id>/stop`：用户手动停止/销毁容器实例（权限校验）。
  - `POST /instances/<instance_id>/extend`：延时容器过期时间（每次 +1 小时）。
  - `GET /instances/<instance_id>/status`：获取容器实例状态与剩余时间。

- `GET /<challenge_id>/stats`
  - 鉴权：公开
  - 描述：返回题目统计（唯一解题人数、总提交数、通过率、首解信息）。

实现要点与注意事项：

- 权限检查：大多数用户操作需要 `@jwt_required()`。管理员接口会进一步检查 `user.is_admin`。
- 提交限速与次数控制由题目属性（`submission_limit`）与 `CtfChallengeSubmission` 计数实现。
- 动态分数与血液奖励由 `ScoringService` 提供，具体算法见 `backend/services/scoring_service.py`。
- 作弊检测调用 `CheatDetectionService.detect_similar_flags`，如发现相似提交会写入 `CtfCheatInfo`。
- 容器操作依赖本地 Docker：`container_service` 在 `backend/services/container_service.py` 中提供创建/销毁/查询等接口；启动容器时会在后台启动流量捕获代理（若启用），并更新实例的 `connection_url`。
- 数据库模型（如 `CtfGameInstance`, `CtfChallengeSubmission` 等）定义在 `backend/server/db_models.py`，文档中引用了 `.to_dict()` 方法用于序列化响应。

建议：可将本文件中的每个端点复制到独立的 Markdown 条目中，补充示例请求/响应与错误码表，便于前端和测试人员使用。
