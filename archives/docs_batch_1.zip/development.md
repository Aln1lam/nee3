# 开发环境与运行指南

建议的本地开发步骤（Python 后端）：

1. 创建并激活虚拟环境：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

2. 安装依赖：如果仓库含 `requirements.txt` 或 `pyproject.toml`，请按文件安装；否则查看 `backend/` 下文档或源码声明的依赖。

3. 启动后端：查看 `backend/app.py` 以获取运行方式（WSGI/ASGI）。常见命令示例：

```powershell
python backend/app.py
# 或 使用 uvicorn/gunicorn 启动（如果为 ASGI）
```

4. 启动前端：参见 `docs/frontend.md`。

测试：

```bash
pip install pytest
pytest -q
```

注意：在执行数据库相关操作前，确认配置文件 `backend/server/config.py` 中的连接信息。
