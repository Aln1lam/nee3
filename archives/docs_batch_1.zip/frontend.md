# 前端（模块概览与运行）

项目前端位于 `frontend/`，基于 Vite：

- 入口：`frontend/index.html`。
- 源代码：`frontend/src/`（`App.vue`、路由、组件、服务等）。
- 依赖与脚本：`frontend/package.json`。

本地启动（常见）：

```bash
cd frontend
npm install
npm run dev
```

构建生产包：

```bash
npm run build
```
