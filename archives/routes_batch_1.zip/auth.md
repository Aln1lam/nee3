# 路由详解：`backend/route/auth.py`

功能：认证与会话管理，包含注册、登录、登出、JWT 刷新、密码重置等接口。

关键端点（示例）：
- `POST /auth/login`：用户登录，返回 JWT。
- `POST /auth/register`：用户注册。
- `POST /auth/refresh`：刷新访问令牌（需要 refresh token）。

鉴权要点：敏感操作返回和密码处理遵循安全最佳实践（哈希、速率限制、邮箱验证）。
