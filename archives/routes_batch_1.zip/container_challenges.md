# 路由详解：`backend/route/container_challenges.py`

功能：容器化题目的专用接口，通常负责容器镜像、网络隔离、题目实例生命周期的高级操作。

关键端点（示例）：
- 启动/停止容器实例，查看容器日志/端口映射，管理网络策略。

实现要点：配合 `backend/services/container_service.py` 使用；注意 Docker 权限与主机资源限制。
