# 路由详解：`backend/route/teams.py`

功能：队伍创建、加入、邀请、成员管理与队伍配置接口。

关键端点（示例）：
- `POST /teams`：创建队伍
- `POST /teams/<id>/invite`：邀请成员
- `GET /teams/<id>`：获取队伍信息与成员列表

注意权限：加入/修改队伍通常需要验证用户身份与邀请码校验。
