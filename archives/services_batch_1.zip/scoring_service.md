# 服务详解：`backend/services/scoring_service.py`

主要类与职责：
- `ScoringService`：动态分数计算、血液奖励、记录首解、更新排行榜、计算排名。
  - 关键方法：`calculate_dynamic_score`, `calculate_blood_bonus`, `record_first_solve`, `update_scoreboard`, `calculate_rankings`。
- `CheatDetectionService`：辅助的作弊检测（字符串相似度、检测相似 Flags）。
- `FlagTemplateService`：根据模板生成动态 Flag。
- `PermissionService` / `FlagValidationService`：权限与 Flag 验证逻辑。

建议：接口已在 `backend/route/challenges.py` 被频繁使用；如需单元测试，可针对 `calculate_dynamic_score` 和 `detect_similar_flags` 编写测试用例。
