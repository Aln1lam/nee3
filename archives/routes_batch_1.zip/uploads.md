# 路由详解：`backend/route/uploads.py`

功能：处理前端上传文件、附件存储、访问权限与文件清理。

关键端点（示例）：
- `POST /uploads`：上传文件（表单/多部分）
- `GET /uploads/<id>`：下载或预览文件

存储注意：文件保存路径为 `static/uploads/`，应限制上传大小和类型检查。
