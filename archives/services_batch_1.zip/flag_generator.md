# 服务详解：`backend/services/flag_generator.py`

职责：解析 Flag 模板并生成动态 Flag，支持 `[GUID]`, `[TEAM_HASH]`, `[LEET]`, `[CLEET]` 等占位符与 Leet 转换。

主要类：`DynamicFlagGenerator`, `ContainerFlagService`。

示例：使用 `ContainerFlagService.generate_dynamic_flag(template, challenge_id, user_id, game_id)`。
