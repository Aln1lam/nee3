# neepu 项目知识库

欢迎使用本仓库生成的知识库。文档包括：项目概览、后端与前端结构、路由与服务详细说明、开发运行指南与常见问题。

快速开始：

- 在本地查看（推荐使用 MkDocs + Material 主题）：参见仓库根目录的 `mkdocs.yml`。
- 文档主页位于本目录下的各个 Markdown 文件，例如 `overview.md`、`backend.md`、`routes.md` 等。

若需在本地构建站点，请参见仓库根目录的 `build_docs.ps1`（或使用 `mkdocs` 命令）。

目录导航：参见站点侧边栏（已由 `mkdocs.yml` 配置）。
