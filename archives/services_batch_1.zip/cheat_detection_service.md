# 服务详解：`backend/services/cheat_detection_service.py`

职责：检测重复/相似提交、快速提交、IP 异常，生成作弊报告并写入 `CtfCheatInfo`。

主要方法：`calculate_similarity`, `detect_duplicate_submission`, `detect_similar_submission`, `detect_rapid_submission`, `detect_ip_pattern`, `create_cheat_record`, `get_cheat_report`。

提示：可根据比赛策略调整阈值（相似度、时间窗口等）。
