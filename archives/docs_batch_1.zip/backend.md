# 后端（模块概览）

主要目录与文件：

- `backend/app.py`：应用入口（启动配置与扩展初始化）。
- `backend/route/`：路由层，按功能划分（认证、挑战、队伍等）。
- `backend/server/`：平台级服务与配置（`config.py`、`db_models.py`、`extensions.py` 等）。
- `backend/services/`：业务服务实现（容器管理、评分、调度等）。

定位路由实现：

- 路由文件位于 [backend/route](backend/route)。常见模块：`challenges.py`、`auth.py`、`uploads.py`、`teams.py` 等。

日志与中间件：

- 中间件实现分为 `middleware/` 与 `middleware_refactored/`，用于缓存、压缩、限流与安全处理。

建议阅读顺序：

1. `backend/app.py`（启动流程）
2. `backend/server/extensions.py`（扩展注册）
3. `backend/route/*.py`（功能路由）
4. `backend/server/services/`（核心业务逻辑）
