# 概览

项目根目录主要内容：

- `backend/`：后端服务与路由实现（Flask / FastAPI 风格结构）。
- `frontend/`：基于 Vite 的前端界面，包含 `src/`、`public/` 等。
- `captures/`：网络流量抓包（PCAP）示例数据，按挑战/团队组织。
- `GZCTF-develop/`：竞赛或平台相关资源与说明。
- `scripts/`：运维或查询脚本（如 `query_db.py`）。

快速阅读路径：

- 后端入口与配置：查看 `backend/app.py` 与 `backend/server/config.py`。
- 路由实现：查看 `backend/route/` 下的各模块（如 `challenges.py`、`auth.py`）。
- 服务层：`backend/server/services/` 下的多个服务（容器、评分、调度等）。
