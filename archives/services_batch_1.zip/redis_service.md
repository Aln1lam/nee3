# 服务详解：`backend/services/redis_service.py`

职责：Redis 连接管理、缓存 API（get/set/json）、排行榜与题目缓存、通知队列、缓存装饰器 `cache_result`。

主要类/函数：`RedisService`, `ScoreboardCache`, `ChallengeCache`, `UserSessionCache`, `NotificationQueue`, `initialize_redis`。

注意：需根据环境进行 `initialize_redis(host, port)`，并在应用启动时创建全局实例。
